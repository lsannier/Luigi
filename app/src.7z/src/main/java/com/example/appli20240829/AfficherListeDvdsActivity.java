package com.example.appli20240829;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class AfficherListeDvdsActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "com.example.appli20240829.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_afficherlistedvds);

        ArrayList<Dvd> dvdList = new ArrayList<>();
        mettreAJourListeDvds(dvdList); // Affichage initial avec données statiques

        try {
            URL urlAAppeler = new URL("http://10.0.2.2:8080/toad/film/all"); // localhost pour émulateur
            new AppelerServiceRestGETTask(this).execute(urlAAppeler, null, null);
        } catch (MalformedURLException mue) {
            Log.d("mydebug", ">>>Pour AppelerServiceRestGETTask - MalformedURLException mue=" + mue.toString());
        }
    }

    public void mettreAJourActivityApresAppelRest(String resultatAppelRest) {
        Log.d("mydebug", ">>>Pour AppelServiceRestActivity - résultat : " + resultatAppelRest);

        // Conversion JSON en liste de DVDs
        ArrayList<Dvd> dvdList = convertirJsonEnListeDvds(resultatAppelRest);

        // Mise à jour de la RecyclerView
        RecyclerView recyclerView = findViewById(R.id.recyclerViewDVD);
        if (recyclerView != null) {
            DVDAdapter adapter = new DVDAdapter(dvdList);
            recyclerView.setAdapter(adapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
        } else {
            Log.e("mydebug", "RecyclerView avec l'ID 'recyclerViewDVD' introuvable.");
        }
    }

    private ArrayList<Dvd> convertirJsonEnListeDvds(String jsonResult) {
        Gson gson = new Gson();
        Type dvdListType = new TypeToken<ArrayList<Dvd>>() {}.getType();
        return gson.fromJson(jsonResult, dvdListType);
    }

    public void mettreAJourListeDvds(ArrayList<Dvd> dvdList) {
        RecyclerView recyclerView = findViewById(R.id.recyclerViewDVD);
        if (recyclerView != null) {
            DVDAdapter adapter = new DVDAdapter(dvdList);
            recyclerView.setAdapter(adapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
        } else {
            Log.e("mydebug", "RecyclerView avec l'ID 'recyclerViewDVD' introuvable.");
        }
    }
}
