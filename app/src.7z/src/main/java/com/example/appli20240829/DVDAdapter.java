package com.example.appli20240829;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DVDAdapter extends RecyclerView.Adapter<DVDAdapter.DVDViewHolder> {

    private final List<Dvd> dvdList;

    // Constructeur
    public DVDAdapter(List<Dvd> dvdList) {
        this.dvdList = dvdList;
    }

    @NonNull
    @Override
    public DVDViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Chargement de l'item XML pour chaque DVD
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_dvd, parent, false);
        return new DVDViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull DVDViewHolder holder, int position) {
        // Récupération du DVD courant dans la liste
        Dvd dvd = dvdList.get(position);

        // Remplissage des TextView avec les données du DVD
        holder.titreTextView.setText(dvd.getTitle());
        holder.genreTextView.setText(dvd.getGenre());
    }

    @Override
    public int getItemCount() {
        return dvdList.size(); // Taille de la liste
    }

    // Classe interne pour gérer chaque item de la RecyclerView
    static class DVDViewHolder extends RecyclerView.ViewHolder {
        TextView titreTextView, genreTextView;

        public DVDViewHolder(@NonNull View itemView) {
            super(itemView);
            // Initialisation des widgets dans l'item XML
            titreTextView = itemView.findViewById(R.id.titreDVD);
            genreTextView = itemView.findViewById(R.id.descriptionDVD);
        }
    }
}
