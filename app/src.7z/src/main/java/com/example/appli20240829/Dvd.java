package com.example.appli20240829;

public class Dvd {
    private String title;
    private int releaseYear;
    private String languageId;
    private int length;
    private String genre; // Nouveau champ pour le genre
    private String description;
    // Constructeur
    public Dvd(String title, int releaseYear, String languageId, int length, String genre) {
        this.title = title;

        this.releaseYear = releaseYear;
        this.languageId = languageId;
        this.length = length;
        this.genre = genre;
        this.description = description;
    }

    // Getters
    public String getTitle() {
        return title;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public String getLanguageId() {
        return languageId;
    }

    public int getLength() {
        return length;
    }

    public String getGenre() {
        return genre;
    }

    public String getdescription() { return description; }

    // Méthode toString pour un affichage clair
    @Override
    public String toString() {
        return "Dvd{" +
                "title='" + title + '\'' +
                ", releaseYear=" + releaseYear +
                ", languageId='" + languageId + '\'' +
                ", length=" + length +
                ", description='" + description + '\'' +
                '}';
    }



}
